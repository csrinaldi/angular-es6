let toReturn = (function () {

  /**
   * Controller to go a new state
   */
  class Controller{

    constructor(){
      //this.$state = $state;
    }

    go(newPlace, params, options) {
      let p = new Promise(function(resolve, reject){
        if (this.$state.is(newPlace)) {
          try {
            this.$state.go(newPlace, params, options);
            resolve();
          }catch(errors){
            reject(errors);
          }
        }else{
          deferred.reject();
        }
      });

      return p;
    }
  }

  return {controller : Controller}


})

export default toReturn.controller;
