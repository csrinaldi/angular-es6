'use strict';
//Import project modules
import coreModule from './core/core';
import securityModule from './services/security/security.config';
import routeModule from './routes/config';

//Angular Main Module
let mainModule = angular.module('MainModule',
    [
        // ngTouch has to be BEFORE ngAria, else ng-clicks happen twice
        'ngTouch',
        'ngAnimate',
        'ngAria',
        'ngMessages',
        'ngResource',
        'ngSanitize',
        'angular-jwt',
        'ngMaterial',
        'restangular',
        'ui.router',
        'ngMdIcons',
        securityModule.name,
        routeModule.name
    ]).config(['$httpProvider', 'jwtInterceptorProvider', 'RestangularProvider', '$mdThemingProvider',
    function ($httpProvider, jwtInterceptorProvider, RestangularProvider,$mdThemingProvider) {
        $mdThemingProvider.theme('default')
          .primaryPalette('light-blue')
          .accentPalette('orange');

        /*RestangularProvider.setBaseUrl('http://localhost:3000/api/');

        jwtInterceptorProvider.tokenGetter = function (config) {
            return localStorage.getItem('token');
        }
        $httpProvider.interceptors.push('jwtInterceptor');*/
    }])
    .run(['$rootScope', '$state', '$document','$window',
        function ($rootScope, $state, $document, $window) {
            console.log("Running Sigit with ES6 and Angular JS 1.3.x");

            $rootScope.$on('$stateChangeStart',
                function (event, toState, toParams, fromState, fromParams) {
                    $state.previus = fromState;
                    $rootScope.$state = $state;
                    //LayoutHandlerService.onHandle(event, toState, toParams, fromState, fromParams);
                }
            );

            $rootScope.$on('users.login.success',
              function () {
                $state.go("full.users.dashboard");
            }
          );


        }]);

export default mainModule;
