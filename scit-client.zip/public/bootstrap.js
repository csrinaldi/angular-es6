'use strict';
import './vendors';
import ES6Promise from 'es6-promise';
import mainModule from './main';

(function() {
  ES6Promise.polyfill();
  angular.element(document).ready(function () {
    angular.bootstrap(document.querySelector('[data-main-app]'),
      [ mainModule.name ]
    );
  });
})()
