/**
 * Created by iron on 22/03/15.
 */
//Import main modules
import 'jquery';
import 'lodash';
import _ from "underscore";
import 'bootstrap';
import 'angular';
import 'router';
import 'angular-animate';
import 'angular-messages';
import 'angular-touch';
import 'angular-aria';
import 'angular-resource';
import 'angular-sanitize';
import 'angular-bootstrap';
import 'angular-jwt';
import 'restangular';
import 'angular-material';
import 'angular-material-icons';
import 'SVG-Morpheus';







