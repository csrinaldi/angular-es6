import _ExportController from './controller';
import _ExportService from './service';
import exportTPL from './template.html!text';

export default (function () {
  class Config {
    constructor($stateProvider) {
      $stateProvider.state(
        'full.process.export', {
          url: '/:id',
          template: exportTPL,
          controller: _ExportController,
          controllerAs: 'vm',
          resolve: {
            distritos: function (ExportService) {
              return ExportService.findDistritos();
            }
          }

        })
    }

    /**
     * This is for this reference
     * @ngInject
     * @returns {UserRouteConfig|*|UserRouteConfig.instance}
     */
    static factory($stateProvider) {
      Config.instance = new Config($stateProvider);
      return Config.instance;
    }
  }

  return angular.module('ExportModule',
    [ 'ui.router' ])
    .controller('ExportController', _ExportController)
    .service('ExportService', _ExportService)
    .config(Config.factory);
})();
