let toReturn = (function () {
  class ExportService {
    constructor($http, $log) {
      this.$http = $http;
      this.$log = $log;
    }

    findDistritos() {
      let vm = this;
      vm.$log.log("Antes de ejecutar la promise")
      let p = new Promise(function(resolve, reject) {
        vm.$http.get('http://10.1.13.5/scitMap/get_distritos.php').success(function (data) {
          console.log(data)
          vm.$http.get('http://10.1.13.5/scitMap/get_vir_layers.php').success(function (response) {
            vm.$log.log("resolviendo promise");
            let obj = {distritos: data, layers: response};
            console.log(obj);
            resolve(obj);
          }).error(function (data) {
            reject(data);
          });
        }).error(function (data) {
          reject(data);
          console.log(data);
        });
      });
      return p;
    }

  }

  return {service : ExportService}
})();

export default toReturn.service;

