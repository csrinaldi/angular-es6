/**
 * Class Imports
 */
import _ProcessController from './controller';
import _ProcessService from './service';

/**
 * Template Imports
 */
import processTPL from './template.html!text';

export default (function () {
  class Config {
    constructor($stateProvider) {
      console.log('UserRouteConfig');
      $stateProvider.state(
        'full.process', {
          url: '/process',
          template: processTPL,
          controller: _ProcessController,
          controllerAs: 'vm',
          resolve: {
            process: function (ProcessService) {
              console.log("Llamando .....");
              return ProcessService.findProcess();
            }
          }
        });
    }

    /**
     * This is for this reference
     * @ngInject
     * @returns {UserRouteConfig|*|UserRouteConfig.instance}
     */
    static factory($stateProvider) {
      Config.instance = new Config($stateProvider);
      return Config.instance;
    }
  }

  return angular.module('ProcessModule',
    [ 'ui.router' ])
    .controller('ProcessController', _ProcessController)
    .service('ProcessService', _ProcessService)
    .config(Config.factory);

})();
