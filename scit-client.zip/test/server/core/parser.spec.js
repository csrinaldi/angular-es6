//var assert = require("assert"); // core module/
var P = require("../../../server/core/parser");

describe('Parser Function', function(){
    /*describe('Module P', function(){
        it('should have a parse Method', function(){
            assert.typeOf(P,'object', 'P is Object');
            assert.typeOf(P.parse,'function', 'P.parse is a Function');
        });
        it('output is Array', function(){
            var result = P.parse("employee:(name,address,domain:(version,ff))");
            var eSpec = ['a'['1','2','b'['3','5'],'6','c'['7']]];
            console.log(result);
        })
        it('Do Parse function', function(){
            assert.typeOf(P.doParse,'function', 'P.doParse is a Function');
            var params = new Object();
            params.text = "employee:(name,address,domain:(version,ff))";
            params.idx = 0;
            var ast = [];
            var result = P.doParse(params, ast);
            console.log(result);
        })
    })*/
});
